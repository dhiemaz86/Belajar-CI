<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Login to the system</title>
	<p> Hallo , <?php echo" $name "?>
</head>
<body>

<div id="container">
	<h1>Welcome to Login system</h1>

	

	<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds</p>
</div>

</body>
</html>